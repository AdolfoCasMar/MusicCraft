MusicCraft Linux alpha: requiere GTK 3, WebKitGTK 4.1 y X11 o XWayland. El filtrado de red no esta integrado. Reproduccion y ventanas requieren pruebas adicionales.
