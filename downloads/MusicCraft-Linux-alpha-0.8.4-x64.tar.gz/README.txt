MusicCraft Linux alpha (x86-64)
Requires GTK 3, WebKitGTK 4.1 and X11 or XWayland.
Experimental: network request filtering is not implemented on this platform. Playback, window docking and background behavior need further testing.
